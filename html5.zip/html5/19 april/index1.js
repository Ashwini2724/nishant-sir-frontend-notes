var c=document.querySelector("canvas");
// console.log(c);
c.width=window.innerWidth;
c.height=window.innerHeight;