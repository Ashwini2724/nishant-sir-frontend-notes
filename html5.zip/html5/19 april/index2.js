var c = document.querySelector("canvas");
// console.log(c);
c.width = window.innerWidth;
c.height = window.innerHeight;

var c1=c.getContext('2d');
c1.fillRect(100,100,100,100);