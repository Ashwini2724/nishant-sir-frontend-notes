var c = document.querySelector("canvas");
// console.log(c);
c.width = window.innerWidth;
c.height = window.innerHeight;

var c1=c.getContext('2d');
c1.fillStyle='red';
c1.fillRect(100,100,100,100);
c1.fillStyle='pink';
c1.fillRect(200,10,300,10);
c1.fillStyle='blue';
c1.fillRect(10,100,10,100);
c1.fillRect(100,120,60,110);


c1.beginPath();
c1.moveTo(50,300);
c1.lineTo(300,100);
c1.moveTo(50,300);
c1.lineTo(300,100);
c1.strokeStyle="blue";
c1.stroke();