var c = document.querySelector("canvas");
// console.log(c);
c.width = window.innerWidth;
c.height = window.innerHeight;

var c1=c.getContext('2d');
c1.fillStyle='red';
c1.fillRect(100,100,100,100);
c1.fillStyle='pink';
c1.fillRect(200,400,300,200);
c1.fillStyle='blue';
c1.fillRect(200,100,10,100);
c1.fillRect(400,120,60,110);
c1.fillRect(500,400,600,400);


c1.beginPath();
c1.moveTo(50,300);
c1.lineTo(300,100);
c1.moveTo(50,300);
c1.lineTo(300,100);
c1.strokeStyle="blue";
c1.stroke();


c1.beginPath();
c1.arc(300,300,30,Math.PI*2,false);
c1.strokeStyle="black";
c1.stroke();