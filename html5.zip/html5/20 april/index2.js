var c = document.querySelector("canvas");
// console.log(c);
c.width = window.innerWidth;
c.height = window.innerHeight;


var c1 = c.getContext("2d");
var x=200;
var vx=10;
function animate() 
{
  requestAnimationFrame(animate);

  c1.clearRect(0,0,innerWidth,innerHeight);
  c1.beginPath();
  c1.arc(x, 200, 30, 0,Math.PI * 2, false);
  c1.strokeStyle = "yellow";
  c1.stroke();
  x+=vx;
}
animate();
