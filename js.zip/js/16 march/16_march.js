var emp=[
    [1,"ashu","sju","priya"]
];
document.write(emp);
 
// var emp2=emp.concat("vaishali");
// document.write(emp2);

// var emp4=emp.concat("xyz")
// var emp3=emp.concat(emp2,emp3,emp4)
// document.write(emp3);

//join
//var emp2=emp.join("_");
//document.write(emp2);

var emp2=emp.slice(1,2);
document.write(emp2);


