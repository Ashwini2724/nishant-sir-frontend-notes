var x=1;

while(x<10){
    document.write("hello world"+"<br />");
    x++;
}