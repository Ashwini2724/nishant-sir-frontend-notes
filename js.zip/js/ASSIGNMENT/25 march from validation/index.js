function hello() {
  var a = document.f1.uname.value;
  var e = document.ename.value;
  var p = document.f1.pname.value;

  if(!isNaN(a)){
         alert("please enter only alphabet");
         return false;
     }
  if(a.length>10){
    alert("mobile no no must be 10 no's");
    return false;
}
if (e.value == "") {
  window.alert(
    "Please enter a valid e-mail address.");
  // email.focus();
  return false;
}
if (p.value == "") {
  window.alert("Please enter your password");
  // password.focus();
  return false;
}


}
