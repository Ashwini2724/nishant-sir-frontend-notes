
class A
{
    add(x,y)
    {
        let z=x+y;
        document.write("sum of:"+z+"<br />");
    }
    sub(x,y)
    {
        let z=x-y;
        document.write("sub of:"+z+"<br />");
    }
    mul(x,y)
    {
        let z=x*y;
        document.write("mul of:"+z+"<br />");
    }
    divi(x,y)
    {
        let z=x/y;
        document.write("sub of:"+z);
    }
}
let a=new A()
a.add(12,23);
a.sub(12,2);
a.mul(12,3);
a.divi(12,12)
