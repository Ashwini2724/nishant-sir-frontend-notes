class A{

            
    constructor()
    {
      let a=10;
      document.write(a) 
       
    }
  
}


let a= new A();
