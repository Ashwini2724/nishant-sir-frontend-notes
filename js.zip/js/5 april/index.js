function hello()
{
    var uname =document.getElementById("uname").ariaValueMax;

    if(uname=="")
    {
        document.getElementById("err").innerHTML="* pel enter username!";
        return false;
    }
    if(uname.length<4)
    {
        document.getElementById("err").innerHTML="lenth must be in bet 4 to 8";
        return false;
    }
    if(uname.length<8)
    {
        document.getElementById("err").innerHTML="lenth must be in bet 4 to 8";
        return false;
    }
    var 
    if(uname.match(pattern))
    {
        document.getElementById("err").innerHTML="only enter char!";
        return false;
    }
}