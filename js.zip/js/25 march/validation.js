function hello()
{
  var a=  document.f1.uname.value;
//   document.write(a);

// if(a==""){
//     alert("enter the username..");
//     return false;
// }
// if(!isNaN(a)){
//     alert("please enter only alphabet");
//     return false;
// }
// if((a.length<4) && (a.length<12))  
// {
//     alert("must be in  bit 4");
//     return false;
// }
if(a.length>10){
    alert("mobile no no must be 10 no's");
    return false;
}
if((a.charAt(0)!=9)&&(a.charAt(0)!=8)&&(a.charAt(0)!=7))
{
    alert("enter valid no")
}

}
