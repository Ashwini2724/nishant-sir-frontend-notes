//innerHTML
// var a=document.getElementById('formdiv').innerHTML;
// console.log(a)

//innerText
// var a=document.getElementById('formdiv').innerText;
// console.log(a)

//links
// var a=document.links;
// console.log(a)

//index
// var a=document.links[2];
// console.log(a)

//
// var a=document.links[2].innerHTML;
// console.log(a)

//attributes
// var a=document.getElementById('formdiv').attributes;
// console.log(a)

//attributes index
// var a=document.getElementById('formdiv').attributes[2];
// console.log(a)

//values
// var a=document.getElementById('formdiv').attributes[0].value;
// console.log(a)

//get by clss name
// var a=document.getElementsByClassName('as');
// console.log(a)

//images
// var a=document.images;
// console.log(a)

//image indexc
// var a=document.images[0];
// console.log(a)

//forms
// var a=document.forms;
// console.log(a)

//froms index
// var a=document.froms[0].innerHTML;
// console.log(a)
