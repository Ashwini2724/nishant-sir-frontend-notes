// function hello()
// {
//     // document.getElementById('mydiv1').innerHTML="we are learning js";
//     var name=document.getElementById('mydiv').value;
//     alert(name)
// }



function color(){
    var name=document.getElementById('mydiv1');
    name.style.color="red";
}