var emp=["ram",23,"male",23000];
document.write(emp+"<br>");

delete emp[1];
document.write(emp+"<br />");

// emp.remove();
// document.write(emp+"<br />");

emp.reverse();
document.write(emp+"<br />");

emp.pop();
document.write(emp+"<br />");

emp.push("mac");
document.write(emp+"<br />");

emp.shift();
document.write(emp+"<br />");

emp.unshift("hey");
document.write(emp+"<br />");





