

var emp=[
    [1,"male","aadi",20000],
    [2,"female","priya",30000],
    [3,"male","suju",40000],
    [4,"female","hema",50000],
    [5,"female","as",60000]
];
//document.write(emp);

document.write("<table border='5'>");
for(var r=0;r<=4;r++)
{
    document.write("<tr>")

    for(var c=0;c<=3;c++)
    {

        document.write(" <td> "+emp[r][c]+"</td>");
    }
    document.write("</tr>")

}
document.write("</table>")


