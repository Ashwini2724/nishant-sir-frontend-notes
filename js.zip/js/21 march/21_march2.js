// var x="cncweb";

// function show()
// {
//     var x="cncweb"
//     document.write(x);
// }
// show();
// document.write(x);

//onlcik event
function add(){
    document.write("hello")
}
