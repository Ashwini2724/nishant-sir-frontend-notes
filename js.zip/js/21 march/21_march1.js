function sum(m,e,h)
{
var s=m+e+h;
return s;
}
function  percentage(total){
    var per =total/300*100;
    document.write(per);

}
var p=sum(75.39,75,75);
percentage(p);