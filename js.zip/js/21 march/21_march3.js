//alert function

// var x=10;
// var y=20;

// if(x<y){
//     alert(x)
// }
// else{
//     alert(y)

// }

//confirm function

// var a=confirm("do you want to continue");
// if(a){
//     alert("thank you")
// }
// else{
//     alert("sorry")
// }
// alert(a);

//prompt function

var m=prompt("enter your name");
// alert("welcome..."+n);

switch(true)
{
    case(m>=80 && m<=100):
    document.write("1 st class");
    break;

    case(m>=60 && m<=79):
    document.write("2nd class");
    break;

    case(m>=40 && m<=79):
    document.write("3rd class");
    break;
    
    default:
        document.write("fail")
    
    
}

