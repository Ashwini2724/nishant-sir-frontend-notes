
//first way
function show(name="cnc",city="pune")
{
 document.write("name is:"+name+"<br>");
 document.write("city is:"+city+"<br>");

}
show("kumar","satara");
show("ashu","wai");
show("suju","mumbai");

//second way
function show(name)
{
return name;
}
document.write("hello"+" "+show("ashu"));
