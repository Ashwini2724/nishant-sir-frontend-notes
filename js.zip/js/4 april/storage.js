export let n ="ashu";


export function show()
{
    console.log("hello everyone");
}
export class myclass
{
    constructor()
    {
        console.log("i am class");
    }
}