import {n ,show,myclass} from "./storage.js";
//import {show} from './storage.js';
//import {myclass} from './storage.js';

console.log("hello "+n);
document.body.innerHTML=n;

show();
let ao=new myclass();

