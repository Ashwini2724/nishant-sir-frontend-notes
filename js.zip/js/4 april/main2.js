import {default as cnc} from "./storage2.js";

cnc();