import * as cnc from "./storage.js";

console.log("hello "+cnc.n);
document.body.innerHTML=cnc.n;

cnc.show("js");
let ao=new cnc.myclass();

