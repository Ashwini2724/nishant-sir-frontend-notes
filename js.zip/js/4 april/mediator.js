export {hello} from "./storage3.js";

