function hello()
{
    console.log("hello its a fun")
}
export {hello};