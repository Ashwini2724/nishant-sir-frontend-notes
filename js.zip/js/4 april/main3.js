
import {hello} from "./mediator.js";

hello();