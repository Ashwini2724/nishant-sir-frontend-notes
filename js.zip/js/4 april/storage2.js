export default function()
{
    console.log("i am default function");
}