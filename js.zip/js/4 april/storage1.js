 let n ="ashu";


 function show(name)
{
    console.log("hello"+name);
}
 class myclass
{
    constructor()
    {
        console.log("i am class");
    }
}
export {n,show,myclass}