
let a=window;
console.log(a);


let aa=window.document;
console.log(aa);


let ab=window.innerWidth;
console.log(a);

