
for(var x=1;x<=100;x++){
    if(x%2==0){
        document.write(x+"<br>")
    }
}