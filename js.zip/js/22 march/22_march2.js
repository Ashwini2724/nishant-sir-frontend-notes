//foreach loop

// var x=[10,20,30,40];

// x.forEach(function(value,index){

//     document.write(index+""+""+value+"<br>");
// });


//second way

var x=[10,20,30,40];

x.forEach();
function hello(index,value){
    document.write(index+""+""+value+"<br>")
}

