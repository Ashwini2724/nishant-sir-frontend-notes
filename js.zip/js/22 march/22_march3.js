

var x="we are are indian";
//lenght
// var l=x.length;
// document.write("length of string"+" "+l);

//lowercase
// var l=x.toLowerCase;
// document.write("lowercase of string"+" "+l);

//uppercase
// var l=x.toUpperCase;
// document.write(l);

 //includes
// var l=x.includes("ashu");
// document.write("includes of string"+" "+l);

//startswitch
// var l=x.startsWith("ian");
// document.write("startsWitch of string"+" "+l);

//search
// var l=x.search("are");
// document.write("search of string"+" "+l);

//match
// var l=x.match(/are/g);
// document.write(l);

//indexof
// var l=x.indexOf("are");
// document.write(l);

//lastindexof
var l=x.lastIndexOf("are");
document.write(l);


