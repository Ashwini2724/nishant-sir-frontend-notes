
setTimeout(hello,7000)

function hello()
{
    document.write("hi");
}
hello();